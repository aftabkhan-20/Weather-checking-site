async function getWeather() {
  const city = document.getElementById('cityInput').value;
  const response = await fetch(`/api/weather?city=${city}`);
  const data = await response.json();

  const display = document.getElementById('weatherDisplay');
  if (data.error) {
    display.innerHTML = `<p>${data.error}</p>`;
  } else {
    display.innerHTML = `
      <h2>${data.name}, ${data.sys.country}</h2>
      <p><strong>${data.weather[0].main}</strong> - ${data.weather[0].description}</p>
      <p>Temperature: ${data.main.temp}°C</p>
      <p>Humidity: ${data.main.humidity}%</p>
    `;
  }
}
