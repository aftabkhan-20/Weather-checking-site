const express = require('express');
const fetch = require('node-fetch');
const cors = require('cors');
const app = express();
const port = 3000;

app.use(cors());
app.use(express.static('.'));

const API_KEY = 'YOUR_OPENWEATHERMAP_API_KEY';

app.get('/api/weather', async (req, res) => {
  const city = req.query.city;
  try {
    const response = await fetch(
      `https://api.openweathermap.org/data/2.5/weather?q=${city},PK&appid=${API_KEY}&units=metric`
    );
    const data = await response.json();
    if (data.cod !== 200) {
      res.json({ error: 'City not found or invalid request.' });
    } else {
      res.json(data);
    }
  } catch (error) {
    res.json({ error: 'Server error.' });
  }
});

app.listen(port, () => {
  console.log(`AK Weather backend running at http://localhost:${port}`);
});
